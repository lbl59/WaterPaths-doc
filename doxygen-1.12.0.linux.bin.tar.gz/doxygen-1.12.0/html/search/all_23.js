var searchData=
[
  ['x_20can_20i_20still_20use_20doxygen_0',['My favorite programming language is X. Can I still use Doxygen?',['../faq.html#faq_pgm_X',1,'']]],
  ['xml_20commands_1',['XML Commands',['../xmlcmds.html',1,'']]],
  ['xml_20output_2',['XML output',['../config.html#config_xml',1,'Configuration options related to the XML output'],['../customize.html#xmlgenerator',1,'Using the XML output'],['../starting.html#xml_out',1,'XML output']]],
  ['xmlinclude_20file_20name_3',['\\xmlinclude &lt;file-name&gt;',['../commands.html#cmdxmlinclude',1,'']]],
  ['xmlonly_4',['\\xmlonly',['../commands.html#cmdxmlonly',1,'']]],
  ['xrefitem_20key_20heading_20list_20title_20text_5',['\\xrefitem \&lt;key\&gt; &quot;heading&quot; &quot;list title&quot; { text }',['../commands.html#cmdxrefitem',1,'']]]
];

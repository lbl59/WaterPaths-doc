var searchData=
[
  ['key_20heading_20list_20title_20text_0',['\\xrefitem \&lt;key\&gt; &quot;heading&quot; &quot;list title&quot; { text }',['../commands.html#cmdxrefitem',1,'']]],
  ['known_20problems_1',['Known Problems',['../trouble.html#knowproblems',1,'']]]
];

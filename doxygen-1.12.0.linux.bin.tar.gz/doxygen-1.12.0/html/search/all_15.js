var searchData=
[
  ['java_0',['Comment blocks for C-like languages (C/C++/C#/Objective-C/PHP/Java)',['../docblocks.html#cppblock',1,'']]]
];

var searching =
[
    [ "External Indexing and Searching", "extsearch.html", [
      [ "Introduction", "extsearch.html#extsearch_intro", null ],
      [ "Configuring", "extsearch.html#extsearch_config", [
        [ "Single project index", "extsearch.html#extsearch_single", null ],
        [ "Multi project index", "extsearch.html#extsearch_multi", null ]
      ] ],
      [ "Updating the index", "extsearch.html#extsearch_update", null ],
      [ "Programming interface", "extsearch.html#extsearch_api", [
        [ "Indexer input format", "extsearch.html#extsearch_api_index", null ],
        [ "Search URL format", "extsearch.html#extsearch_api_search_in", null ],
        [ "Search results format", "extsearch.html#extsearch_api_search_out", null ]
      ] ]
    ] ]
];